# ShelfWare

ShelfWare is a lightweight shelf-aware grocery inventory system built as a DBMS mini-project. It pairs a small Flask API with static HTML/CSS/JS pages and a SQLite database to demonstrate catalog browsing, simple checkout, inventory visibility, forecasting, and procurement workflows.

This repository is prepared for sharing on GitHub. Local data files (SQLite DB, CSV exports, backups) are intentionally excluded from version control — see `.gitignore`.

Key features
- Product catalog with search, categories and pagination
- Customer storefront with cart and checkout (stores cart in localStorage)
- Admin dashboards (KPIs, recent sales, top products)
- Inventory views (stock levels, expiring soon)
- ML-backed forecasts (Random Forest) and procurement recommendations

Project layout
- `shelfware_bundle/` — main application files and Flask API (`unified_api_server.py`)
- `UI/` — (legacy) copies of static pages; keep for reference
- `*.csv` — optional data exports (not tracked)
- `employees.db` — local SQLite DB used during development (not tracked)

See `HOW_TO_RUN.md` for a step-by-step guide to run the app locally.

If you'd like me to also remove specific files (for example: CSV data dumps, local DB backups, or UI duplicates), tell me which items you want removed and I will clean them up and update this README accordingly.

---
Last updated: October 31, 2025